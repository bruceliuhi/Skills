# Visual style: vintage-poster

Mid-century print poster (1950s–1970s) — bold rounded-geometric shapes, limited flat color blocks, halftone / paper grain, retro warmth. For cultural decks, brand storytelling, hospitality, retro-tech narratives, anniversaries, heritage brands.

---

## 1. Shape & decoration

- Shape language: bold geometric shapes with rounded organic edges, often slightly off-axis for retro tension; overlapping flat blocks; thick hand-aware lines; stylized, reduced iconography (a stylized sun, an angular mountain).
- Composition geometry: a giant sun disc or arch as the backdrop anchor; ray wedges radiating from the focal point; off-axis overlapping blocks staging the content; a horizon band splitting the page into field and sky zones; one badge or rosette seal at the emphasis point.
- Decoration: the print artifacts — halftone dot overlays, slight ink misregistration — carry the character. Generated illustration stays reduced and graphic. Required documentary photography remains eligible; integrate it through crop, tonal reduction, halftone, or another print treatment instead of replacing the real subject with invented imagery.
- Whitespace: confident poster composition — a few large blocks, deliberate negative space.

## 2. Typography character

- Retro display character for headlines (mid-century geometric, confident); a simple legible body by contrast.

> Families are chosen at confirmation `g`; this style asks for a mid-century display *character*. This governs editable native text; decorative-lettering eligibility remains a separate carrier decision.

## 3. Using the deck's colors

- Applied as limited flat blocks (a small set of colors): the primary dominates large blocks, the secondary reads as a warm paper field, the accent marks small shapes or tints the halftone.
- Flat color only — no gradients; depth comes from overlap, not blending.

> HEX values come from confirmation `e`; this style only governs the limited-flat-block, halftone discipline — it names no colors.

## 4. Texture / elevation

- Flat — depth implied via overlapping shapes, never via shadow. Halftone dot pattern or paper grain at low opacity gives printed age; slight ink-offset character is on-brand.

## 5. Paired image-rendering

`vintage-poster` — mid-century poster imagery with matching halftone and retro-geometric warmth.

## 6. Illustration propensity

**core** — when illustration is selected, mid-century motifs and halftone cuts may lead the poster look. Role, scale, reuse, and placement stay Strategist judgment; an explicit user request wins either way, and `image_usage: none` writes no illustration rows.
